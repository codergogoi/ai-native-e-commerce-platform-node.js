# Embeddings and OpenSearch source snapshot (b9-end)

Backend at the end of Episode 10. Every product now carries an OpenAI embedding
stored as a kNN vector in OpenSearch. This is the indexing half of semantic
search; the query endpoint arrives in Episode 11.

What this episode added
- OpenSearch (plus a named volume) in the root docker-compose.yml
- EmbeddingService wrapping OpenAI text-embedding-3-small (single + batch + buildEmbeddingText)
- SearchService: OpenSearch client, createIndexIfNotExists with a knn_vector mapping
  (dimension 1536, HNSW/L2), indexProduct, bulkIndexProducts, deleteIndex
- A @Global() SearchModule wired into AppModule, so both services inject anywhere
- seed.ts now embeds every product in batches and bulk-indexes them after the Postgres seed
- (Also present from Episode 9: the orders module, create/find, auth-guarded)

Required env vars (placeholders in .env.example)
- DATABASE_URL, JWT_SECRET, JWT_REFRESH_SECRET, PORT
- OPENAI_API_KEY (key with embeddings access)
- OPENSEARCH_NODE (defaults to http://localhost:9200)

Run it
1. cp .env.example .env  (fill placeholders, including a real OPENAI_API_KEY)
2. docker compose up -d           # Postgres + OpenSearch; give OpenSearch ~30s
3. npm install
4. cd backend && npx prisma migrate dev && cd ..
5. npm run seed --workspace=backend
6. npm run dev:backend

It works when
- The seed prints "Indexed 201 products in OpenSearch with embeddings"
- curl 'localhost:9200/products/_count' returns {"count":201,...}
- curl 'localhost:9200/products/_mapping?pretty' shows embedding as a knn_vector, dimension 1536
