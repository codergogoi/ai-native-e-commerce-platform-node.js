import { Module, Global } from '@nestjs/common';
import { SearchService } from './search.service';
import { EmbeddingService } from './embedding.service';

@Global()
@Module({
  providers: [SearchService, EmbeddingService],
  exports: [SearchService, EmbeddingService],
})
export class SearchModule {}
