import {
  Injectable,
  NotFoundException,
  ForbiddenException,
} from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { ProductQueryDto } from './dto/product-query.dto';
import { Product } from './interfaces/product.interface';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';

function toProduct(p: {
  id: string;
  name: string;
  description: string;
  price: Prisma.Decimal;
  category: string;
  image: string;
  rating: Prisma.Decimal;
  inStock: boolean;
  features: string[];
  [key: string]: any;
}): Product {
  return {
    id: p.id,
    name: p.name,
    description: p.description,
    price: Number(p.price),
    category: p.category,
    image: p.image,
    rating: Number(p.rating),
    inStock: p.inStock,
    features: p.features,
    salePrice: p.salePrice != null ? Number(p.salePrice) : null,
    dealExpiresAt:
      p.dealExpiresAt instanceof Date
        ? p.dealExpiresAt.toISOString()
        : (p.dealExpiresAt ?? null),
    sellerId: p.sellerId ?? null,
  };
}

@Injectable()
export class ProductsService {
  constructor(private readonly prisma: PrismaService) {}

  async create(dto: CreateProductDto, sellerId: string): Promise<Product> {
    const product = await this.prisma.product.create({
      data: {
        name: dto.name,
        description: dto.description,
        price: dto.price,
        category: dto.category,
        image: dto.image,
        features: dto.features,
        rating: dto.rating ?? 0,
        inStock: dto.inStock ?? true,
        sellerId,
      },
    });

    return toProduct(product);
  }

  async update(
    id: string,
    dto: UpdateProductDto,
    sellerId: string,
  ): Promise<Product> {
    const existing = await this.prisma.product.findUnique({ where: { id } });
    if (!existing) {
      throw new NotFoundException(`Product with id "${id}" not found`);
    }
    if (existing.sellerId !== sellerId) {
      throw new ForbiddenException('You can only edit your own products');
    }

    const updated = await this.prisma.product.update({
      where: { id },
      data: dto,
    });
    return toProduct(updated);
  }

  async findBySellerId(sellerId: string): Promise<Product[]> {
    const rows = await this.prisma.product.findMany({
      where: { sellerId },
      orderBy: { updatedAt: 'desc' },
    });
    return rows.map(toProduct);
  }

  async findAll(
    query: ProductQueryDto,
  ): Promise<{ products: Product[]; total: number }> {
    const where: Prisma.ProductWhereInput = {};

    if (query.category) {
      where.category = query.category;
    }
    if (query.minPrice || query.maxPrice) {
      where.price = {
        ...(query.minPrice ? { gte: Number(query.minPrice) } : {}),
        ...(query.maxPrice ? { lte: Number(query.maxPrice) } : {}),
      };
    }
    if (query.search) {
      where.OR = [
        { name: { contains: query.search, mode: 'insensitive' } },
        { description: { contains: query.search, mode: 'insensitive' } },
      ];
    }

    const rows = await this.prisma.product.findMany({
      where,
      orderBy: { rating: 'desc' },
    });
    const products = rows.map(toProduct);
    return { products, total: products.length };
  }

  async getDeals(): Promise<Product[]> {
    const now = new Date();
    const rows = await this.prisma.product.findMany({
      where: {
        salePrice: { not: null },
        OR: [{ dealExpiresAt: null }, { dealExpiresAt: { gt: now } }],
      },
      orderBy: { updatedAt: 'desc' },
    });
    return rows.map(toProduct);
  }

  async findById(id: string): Promise<Product | null> {
    const p = await this.prisma.product.findUnique({ where: { id } });
    return p ? toProduct(p) : null;
  }

  async getCategories(): Promise<string[]> {
    const results = await this.prisma.product.findMany({
      select: { category: true },
      distinct: ['category'],
      orderBy: { category: 'asc' },
    });
    return results.map((r) => r.category);
  }
}
