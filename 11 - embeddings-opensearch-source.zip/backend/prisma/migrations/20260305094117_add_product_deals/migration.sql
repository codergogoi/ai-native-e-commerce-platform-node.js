ALTER TABLE "products" ADD COLUMN     "dealExpiresAt" TIMESTAMP(3),
ADD COLUMN     "salePrice" DECIMAL(10,2);
