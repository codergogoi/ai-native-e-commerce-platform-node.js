import { Controller, Post, Body, Res } from '@nestjs/common';
import type { Response } from 'express';
import { ChatService } from './chat.service';
import { ChatMessageDto } from './dto/chat-message.dto';
import { ProductsService } from '../products/products.service';

@Controller('chat')
export class ChatController {
  constructor(
    private readonly chatService: ChatService,
    private readonly productsService: ProductsService,
  ) {}

  @Post()
  async chat(@Body() dto: ChatMessageDto, @Res() res: Response) {
    res.setHeader('Content-Type', 'text/event-stream');
    res.setHeader('Cache-Control', 'no-cache');
    res.setHeader('Connection', 'keep-alive');

    try {
      for await (const event of this.chatService.streamChat(
        dto.message,
        dto.history,
      )) {
        if (event.type === 'text') {
          res.write(
            `data: ${JSON.stringify({ type: 'text', content: event.content })}\n\n`,
          );
        } else if (event.type === 'products') {
          const products = await this.productsService.findByIds(
            event.productIds!,
          );
          res.write(
            `data: ${JSON.stringify({ type: 'products', products })}\n\n`,
          );
        }
      }
      res.write(`data: ${JSON.stringify({ type: 'done' })}\n\n`);
    } catch (error) {
      res.write(
        `data: ${JSON.stringify({ type: 'error', error: 'Failed to generate response' })}\n\n`,
      );
    }
    res.end();
  }
}
