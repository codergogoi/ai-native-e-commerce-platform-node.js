import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';
import { ProductsService } from '../products/products.service';
import { isProductOnDeal } from '../products/products.service';
import { ChatMessage, ChatStreamEvent } from './interfaces/chat.interface';
import { Product } from '../products/interfaces/product.interface';

@Injectable()
export class ChatService {
  private openai: OpenAI;

  constructor(
    private configService: ConfigService,
    private productsService: ProductsService,
  ) {
    this.openai = new OpenAI({
      apiKey: this.configService.get<string>('OPENAI_API_KEY'),
    });
  }
  private readonly tools: OpenAI.Chat.Completions.ChatCompletionTool[] = [
    {
      type: 'function',
      function: {
        name: 'show_products',
        description:
          'Show product cards to the user so they can browse and add to cart. Call this whenever you recommend or mention specific products.',
        parameters: {
          type: 'object',
          properties: {
            productIds: {
              type: 'array',
              items: { type: 'string' },
              description: 'Array of product IDs to show as cards',
            },
          },
          required: ['productIds'],
        },
      },
    },
  ];
  private buildSystemPrompt(products: Product[]): string {
    const productList = products
      .map((p) => {
        const onDeal = isProductOnDeal(p);
        const priceStr = onDeal
          ? `ON SALE $${p.salePrice} (was $${p.price})`
          : `$${p.price}`;
        return `- [ID: ${p.id}] ${p.name} (${priceStr}) [${p.category}]: ${p.description}. Features: ${p.features.join(', ')}. ${p.inStock ? 'In Stock' : 'Out of Stock'}. Rating: ${p.rating}/5`;
      })
      .join('\n');

    return `You are a friendly AI shopping assistant for an e-commerce store called "AI E-Commerce".

YOUR ROLE:
- Recommend products by IMMEDIATELY calling the show_products function with product IDs
- Help customers compare options and make decisions
- Be enthusiastic but not pushy

AVAILABLE PRODUCTS:
${productList}

RULES:
- ALWAYS call show_products when you recommend or mention specific products
- Write a brief recommendation explaining why these products are great picks
- Recommend REAL products from the list above, never invent product ids, prices, or stock
- Keep responses short and friendly`;
  }
  async *streamChat(
    message: string,
    history: ChatMessage[],
  ): AsyncGenerator<ChatStreamEvent> {
    const relevantProducts =
      await this.productsService.searchByRelevance(message);

    const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
      { role: 'system', content: this.buildSystemPrompt(relevantProducts) },
      ...history.map((h) => ({
        role: h.role as 'user' | 'assistant',
        content: h.content,
      })),
      { role: 'user' as const, content: message },
    ];

    const stream = await this.openai.chat.completions.create({
      model: 'gpt-4o-mini',
      stream: true,
      temperature: 0.7,
      tools: this.tools,
      parallel_tool_calls: false,
      messages,
    });
    const toolAcc: Record<number, { id: string; name: string; args: string }> =
      {};

    for await (const chunk of stream) {
      const choice = chunk.choices[0];
      if (!choice) continue;

      if (choice.delta?.content) {
        yield { type: 'text', content: choice.delta.content };
      }

      for (const tc of choice.delta?.tool_calls ?? []) {
        const i = tc.index;
        if (!toolAcc[i]) toolAcc[i] = { id: '', name: '', args: '' };
        if (tc.id) toolAcc[i].id = tc.id;
        if (tc.function?.name) toolAcc[i].name = tc.function.name;
        if (tc.function?.arguments) toolAcc[i].args += tc.function.arguments;
      }
    }
    const toolCalls = Object.values(toolAcc).filter((t) => t.name);
    for (const t of toolCalls) {
      if (t.name !== 'show_products') continue;
      let args: { productIds?: string[] } = {};
      try {
        args = JSON.parse(t.args || '{}');
      } catch {
      }

      const ids = args.productIds ?? [];
      if (ids.length) yield { type: 'products', productIds: ids };
    }
    if (toolCalls.length === 0) return;

    messages.push({
      role: 'assistant',
      content: null,
      tool_calls: toolCalls.map((t) => ({
        id: t.id,
        type: 'function',
        function: { name: t.name, arguments: t.args || '{}' },
      })),
    });
    for (const t of toolCalls) {
      messages.push({
        role: 'tool',
        tool_call_id: t.id,
        content:
          'The product cards are now on screen. Reply in one or two short sentences and do not list the products.',
      });
    }

    const followUp = await this.openai.chat.completions.create({
      model: 'gpt-4o-mini',
      stream: true,
      temperature: 0.7,
      messages,
    });

    for await (const chunk of followUp) {
      const text = chunk.choices[0]?.delta?.content;
      if (text) yield { type: 'text', content: text };
    }
  }
}
