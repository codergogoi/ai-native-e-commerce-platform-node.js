export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface ChatStreamEvent {
  type: 'text' | 'products';
  content?: string;
  productIds?: string[];
}
