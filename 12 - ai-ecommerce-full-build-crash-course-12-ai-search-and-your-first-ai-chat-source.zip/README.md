# AI Chat — Streaming and Tool Calling source snapshot (b12-end)

Backend at the end of Episode 13: the store gets a brain. One `POST /api/chat`
opens a Server-Sent Events response that streams the model's answer token by
token, and the model can call a `show_products` tool whose ids we resolve into
real catalog rows and push as a `products` event.

What this episode added (b12-end)
- `ChatModule` (imports `ProductsModule`), registered in `AppModule`
- `ChatMessageDto` — the message plus a validated `history` array (`@IsIn` locks
  the role to user/assistant, `@ValidateNested` + `@Type` check every item)
- `ChatStreamEvent` / `ChatMessage` interfaces — a `text` event and a
  `products` event
- `ChatService.streamChat()` — an async generator: RAG retrieve via
  `searchByRelevance` -> grounded system prompt -> streaming completion ->
  yield text deltas live -> accumulate the tool call across deltas -> run
  `show_products` once the stream is exhausted (`parallel_tool_calls: false`)
  -> hand the tool result back and stream one follow-up completion, so the
  shopper gets the cards first and then a short reply about them
- `ChatController` — `@Res()` manual streaming: three SSE headers, one
  `data: ...\n\n` frame per event, `findByIds` hydration for product events, a
  `done` frame at the end and an `error` frame if anything throws
- `ProductsService` gains `searchByRelevance()` (embedding + kNN -> ordered
  rows), `findByIds()` (id-ordered hydration) and the exported
  `isProductOnDeal()` helper the system prompt uses for sale pricing

Carried forward
- Smart search router (b11), embeddings + OpenSearch (b9/b10), orders (b8),
  auth + roles (b6-b8), products API, seed + validation, Prisma
- Not here yet: cart tools (B14), the agent loop (B15), cart grounding (B16),
  personalization / history (B17), guest sessions (B18)

Run it
- `docker compose up -d` (Postgres + OpenSearch)
- `npm install`
- `npx prisma migrate dev --schema backend/prisma/schema.prisma` (from the repo root)
- `npm run seed --workspace=backend`
- `npm run dev:backend`

Environment (monorepo root `.env`)
- DATABASE_URL, JWT_SECRET, JWT_REFRESH_SECRET, OPENSEARCH_NODE, OPENAI_API_KEY

It works when
A streaming chat POST returns a real products event, then text deltas, then done:

    curl -N -X POST http://localhost:3000/api/chat \
      -H 'Content-Type: application/json' \
      -d '{"message":"show me wireless headphones","history":[]}'

    # data: {"type":"products","products":[{...}]}
    # data: {"type":"text","content":"Here"}
    # data: {"type":"text","content":" are"}
    # data: {"type":"done"}
