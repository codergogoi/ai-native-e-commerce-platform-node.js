# Auth 3 of 3 source snapshot (b7-end)

Backend at the end of Episode 8: roles and protected routes. Authentication complete.

What this episode added
- @Roles() decorator (SetMetadata) + RolesGuard (Reflector + request.user.role)
- OptionalJwtAuthGuard (never rejects; used later for chat/guest personalization)
- Seller-only guard stacks on POST /api/products, PATCH /api/products/:id, GET /api/products/seller
- CreateProductDto / UpdateProductDto; create stamps sellerId from the token; update has an ownership check

Run it
1. cp .env.example .env (fill placeholders)
2. docker compose up -d
3. npm install
4. cd backend && npx prisma migrate dev && cd ..
5. npm run seed --workspace=backend
6. npm run dev:backend

It works when
- POST /api/products with the BUYER token returns 403, with the SELLER token returns 201
- GET /api/products/seller lists only the sellers own products
- Public browse routes (list/categories/deals/:id) still work with no token
