# Episode 3 — Prisma and Your First Table (b2-end)

This snapshot is the project as it stands at the end of Episode 3: the Prisma
schema with the `Role` enum and the `User`, `Product`, `Order`, and `OrderItem`
models, the `init` migration, and a global `PrismaModule` / `PrismaService`
wired into the NestJS app.

## Run it

```bash
cp .env.example .env            # fill in placeholders (DATABASE_URL works as-is)
npm install                     # from this folder (workspace root)
docker compose up -d            # start Postgres (container: ecommerce-postgres)
cd backend
ln -s ../.env .env              # make DATABASE_URL visible to the Prisma CLI
npx prisma migrate dev          # apply the init migration
cd .. && npm run dev:backend    # boot NestJS on http://localhost:3000/api
npx prisma studio               # (from backend/) browse tables on :5555
```

## Env vars

Only `DATABASE_URL` is used so far; the other keys in `.env.example` are
placeholders for later episodes.

## It works when…

`npx prisma migrate dev` prints "Your database is now in sync with your schema",
Prisma Studio lists User, Product, Order, and OrderItem, and `npm run
dev:backend` boots with `PrismaModule dependencies initialized` and no errors.
