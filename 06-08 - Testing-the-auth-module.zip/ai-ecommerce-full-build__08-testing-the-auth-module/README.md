# Auth 2 of 3 source snapshot (b6-end)

This is the backend at the end of Episode 7: refresh tokens + Passport guards.

What this episode added
- generateTokens: 15m access token (JWT_SECRET) + 7d refresh token (JWT_REFRESH_SECRET)
- Refresh token stored bcrypt-hashed on the user row; rotation on every refresh
- strategies/jwt.strategy.ts + strategies/jwt-refresh.strategy.ts
- guards/jwt-auth.guard.ts + decorators/current-user.decorator.ts
- POST /api/auth/refresh (jwt-refresh) and POST /api/auth/logout (JwtAuthGuard)

Run it
1. cp .env.example .env  (fill placeholders; set distinct JWT_SECRET and JWT_REFRESH_SECRET)
2. docker compose up -d
3. npm install
4. npx prisma migrate dev --workspace not needed: run inside backend/  (cd backend && npx prisma migrate dev)
5. npm run seed --workspace=backend
6. npm run dev:backend

It works when
- POST /api/auth/login returns { user, accessToken, refreshToken }
- POST /api/auth/logout: 401 without a token, 200 with a Bearer access token
- POST /api/auth/refresh with the refresh token returns a new pair; replaying the old one returns 403
