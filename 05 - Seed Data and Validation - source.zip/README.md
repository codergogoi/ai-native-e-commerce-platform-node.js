# Episode 5 — Seed Data and Validation (b4-end)

This snapshot adds a real seed script and request validation on top of the
Products API from Episode 4:

- `backend/src/seed.ts` — boots a headless Nest context, clears old rows in
  FK-safe order, creates a demo seller/buyer (bcrypt-hashed passwords), and
  inserts the 201-product catalog with Prisma.
- `backend/src/products/dto/product-query.dto.ts` — class-validator rules on
  the list endpoint's query params, enforced by the global `ValidationPipe`.
- `"seed"` script in `backend/package.json` (`nest build && node dist/seed.js`).

## Run it

```bash
cp .env.example .env          # placeholder values work for local dev
docker compose up -d          # Postgres 16 on :5432
npm install
cd backend && npx prisma migrate dev && cd ..
npm run seed --workspace=backend
npm run dev:backend           # API on http://localhost:3000/api
```

It works when `npm run seed` prints "Seeded 201 products into PostgreSQL",
`curl -s localhost:3000/api/products | jq '.total'` returns 201, and
`/api/products?minPrice=banana` returns a 400 validation error.

Demo logins: seller@ai-ecommerce.com / admin123, buyer@ai-ecommerce.com / admin123.
