# Episode 4 — The Products API (b3-end)

This snapshot is the project at the end of Episode 4: the `products` slice.
A `Product` interface (the JSON contract), a `ProductQueryDto` with validated
filters, a `ProductsService` with the `toProduct` Decimal-to-number mapper and
`findAll` / `findById` / `getCategories` / `getDeals`, a read-only
`ProductsController` (`GET /api/products`, `/categories`, `/deals`, `/:id`
with static-before-`:id` ordering and a clean `NotFoundException` 404), and
`ProductsModule` wired into `app.module.ts`. The schema gained two nullable
deal columns (`salePrice`, `dealExpiresAt`) via the `add_product_deals` migration.

## Run it

```bash
cp .env.example .env            # fill in placeholders (DATABASE_URL works as-is)
npm install                     # from this folder (workspace root)
docker compose up -d            # start Postgres (container: ecommerce-postgres)
cd backend
ln -s ../.env .env              # make DATABASE_URL visible to the Prisma CLI
npx prisma migrate dev          # apply init + add_product_deals migrations
cd .. && npm run dev:backend    # boot NestJS on http://localhost:3000/api
```

## Env vars

Only `DATABASE_URL` is used so far; the other keys in `.env.example` are
placeholders for later episodes.

## It works when…

`curl -s http://localhost:3000/api/products | jq '.total'` returns a count,
`/api/products/categories` and `/api/products/deals` resolve to their own
handlers (not `:id`), a real product id returns its JSON with `price` as a
plain number, and `/api/products/not-a-real-id` returns a 404 JSON body.
The table is empty until the seed lands in Episode 5, so add a few rows with
Prisma Studio (`npx prisma studio`) to see data.
