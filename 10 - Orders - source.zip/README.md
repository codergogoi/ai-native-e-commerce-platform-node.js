# Orders source snapshot (b8-end)

Backend at the end of Episode 9: a working orders system on top of the finished auth stack.

What this episode added
- Activated the Order / OrderItem models (already present in the init migration since Episode 3) — no new migration needed
- CreateOrderDto with nested class-validator (@ValidateNested + @Type on the items array); no `total` field, on purpose
- OrdersService: `create` computes the total server-side and saves the order + all items in one Prisma nested write (single transaction), plus `findByUserId`, `findById`, and `findRecentByUserId`, all with a two-level `include: { items: { include: { product } } }`
- OrdersController behind `@UseGuards(JwtAuthGuard)`: POST / GET / GET :id, with `@CurrentUser('id')` stamping the owner from the token and `null` turned into a 404
- OrdersModule wired into app.module.ts

Run it
1. cp .env.example .env (fill placeholders)
2. docker compose up -d
3. npm install
4. cd backend && npx prisma migrate dev && cd ..
5. npm run seed --workspace=backend
6. npm run dev:backend

It works when
- Log in (buyer@ai-ecommerce.com / admin123) to get an accessToken
- POST /api/orders with a Bearer token and an `items` array returns 201, and `total` is the server-computed sum
- GET /api/orders lists your orders newest-first, each with items and their products populated
- GET /api/orders/<unknown-id> returns a clean 404
