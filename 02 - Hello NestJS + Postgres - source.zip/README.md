# Episode 2 — Hello NestJS + Postgres (b1-end)

State of the project at the end of Episode 2: a scaffolded NestJS backend
(global `/api` prefix, validation, CORS for the future frontend) that reads the
monorepo-root `.env` via `@nestjs/config`, plus a PostgreSQL 16 container
described in the root `docker-compose.yml`.

## Run it

```bash
cp .env.example .env        # placeholder dev values, edit if needed
npm install                 # installs the backend workspace
docker compose up -d        # starts ecommerce-postgres on port 5432
npm run dev:backend         # boots NestJS on http://localhost:3000
```

## Env vars (placeholders)

`DB_HOST`, `DB_PORT`, `DB_USERNAME`, `DB_PASSWORD`, `DB_NAME` — must match the
`postgres` service in `docker-compose.yml`. Nothing consumes them yet; Prisma
does in the next episode.

## It works when…

`docker ps` shows `ecommerce-postgres` up, and `GET http://localhost:3000/api`
returns `Hello World!`.
