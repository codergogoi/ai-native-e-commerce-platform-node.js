# Cart Grounding & Guardrails source snapshot (b15-end)

Backend at the end of Episode 16: the AI agent is now **grounded in the real cart** and
kept honest by **guardrails**, so it quotes exact totals and adds exactly what you asked.

What this episode added (all in `backend/src/chat/chat.service.ts`)
- A typed `CartLine` interface for the server-side view of a cart line.
- `workingCart` — a per-request shallow clone of the browser's cart
  (`cart.map((c) => ({ ...c }))`) that the tools mutate, so the caller's array is never
  touched and totals stay accurate as the agent works.
- `buildCartContext(cart)` — turns the cart into a prompt block ("CURRENT CART ... total
  $X ... use THESE exact figures") and is stitched into `buildSystemPrompt`, near the top
  where the model reads carefully. The cart is passed `streamChat -> buildSystemPrompt`.
- `cartSummary(cart)` — returns `{ items, itemCount, total }` with a two-decimal numeric
  total; every cart tool (`add_to_cart`, `remove_from_cart`, `update_cart_quantity`)
  returns it so the model always sees the fresh total on its next turn.
- Deal-aware pricing: `add_to_cart` charges `salePrice` when `isProductOnDeal(p)` is true,
  and the product list is labelled `ON SALE $x (was $y)`.
- Guardrails in the system prompt: a `CART MANAGEMENT` block where "add the best one"
  means EXACTLY ONE `add_to_cart` call, plus the anti-double-add `quantity += 1` guard in
  the tool itself, and "never invent product ids, prices, or stock".
- `remove_from_cart` / `update_cart_quantity` return `{ error: 'Not in cart', cart }` before any
  event when the id is not in the working cart; the cart context lists each line with its
  `[ID: ...]`, and the prompt says quantity changes go through `update_cart_quantity` only.
- `parallel_tool_calls: false` on the agent loop's completion: one tool call per round.

Not in this snapshot yet (later episodes): personalization / history (b16), guest
sessions (b17), seller backend (b18), order cancellation + support tickets (b19).

Run it
1. cp .env.example .env (fill placeholders, set `OPENAI_API_KEY`)
2. docker compose up -d
3. npm install
4. npx prisma migrate dev --schema backend/prisma/schema.prisma (from the repo root)
5. npm run seed --workspace=backend
6. npm run dev:backend

It works when
- You POST a message with a non-empty `cart` and the streamed reply quotes the CORRECT
  total, and adding the SAME item twice bumps the line to quantity 2 (no duplicate row)
  with an exact summed total:
  ```
  curl -N -X POST http://localhost:3000/api/chat \
    -H 'Content-Type: application/json' \
    -d '{"message":"add the iPhone 15 to my cart, then add it again, and tell me my total",
         "history":[],
         "cart":[{"productId":"p1","name":"iPhone 15","price":999,"quantity":1}]}'
  ```

Required env (placeholders only)
- `OPENAI_API_KEY=sk-your-key-here`
- `DATABASE_URL`, `JWT_SECRET`, `JWT_REFRESH_SECRET`, `OPENSEARCH_NODE` per `.env.example`
