import {
  Injectable,
  NotFoundException,
  ForbiddenException,
} from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import { ProductQueryDto } from './dto/product-query.dto';
import { SearchService } from '../search/search.service';
import { EmbeddingService } from '../search/embedding.service';
import { Product } from './interfaces/product.interface';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';

function toProduct(p: {
  id: string;
  name: string;
  description: string;
  price: Prisma.Decimal;
  category: string;
  image: string;
  rating: Prisma.Decimal;
  inStock: boolean;
  features: string[];
  [key: string]: any;
}): Product {
  return {
    id: p.id,
    name: p.name,
    description: p.description,
    price: Number(p.price),
    category: p.category,
    image: p.image,
    rating: Number(p.rating),
    inStock: p.inStock,
    features: p.features,
    salePrice: p.salePrice != null ? Number(p.salePrice) : null,
    dealExpiresAt:
      p.dealExpiresAt instanceof Date
        ? p.dealExpiresAt.toISOString()
        : (p.dealExpiresAt ?? null),
    sellerId: p.sellerId ?? null,
  };
}

export function isProductOnDeal(p: Product): boolean {
  if (p.salePrice == null || p.salePrice >= p.price) return false;
  if (p.dealExpiresAt && new Date(p.dealExpiresAt).getTime() <= Date.now()) {
    return false;
  }
  return true;
}

@Injectable()
export class ProductsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly searchService: SearchService,
    private readonly embeddingService: EmbeddingService,
  ) {}

  async create(dto: CreateProductDto, sellerId: string): Promise<Product> {
    const product = await this.prisma.product.create({
      data: {
        name: dto.name,
        description: dto.description,
        price: dto.price,
        category: dto.category,
        image: dto.image,
        features: dto.features,
        rating: dto.rating ?? 0,
        inStock: dto.inStock ?? true,
        sellerId,
      },
    });

    return toProduct(product);
  }

  async update(
    id: string,
    dto: UpdateProductDto,
    sellerId: string,
  ): Promise<Product> {
    const existing = await this.prisma.product.findUnique({ where: { id } });
    if (!existing) {
      throw new NotFoundException(`Product with id "${id}" not found`);
    }
    if (existing.sellerId !== sellerId) {
      throw new ForbiddenException('You can only edit your own products');
    }

    const updated = await this.prisma.product.update({
      where: { id },
      data: dto,
    });
    return toProduct(updated);
  }

  async findBySellerId(sellerId: string): Promise<Product[]> {
    const rows = await this.prisma.product.findMany({
      where: { sellerId },
      orderBy: { createdAt: 'desc' },
    });
    return rows.map(toProduct);
  }

  async findByIds(ids: string[]): Promise<Product[]> {
    if (ids.length === 0) return [];
    const rows = await this.prisma.product.findMany({
      where: { id: { in: ids } },
    });
    const productMap = new Map(rows.map((p) => [p.id, toProduct(p)]));
    return ids
      .map((id) => productMap.get(id))
      .filter((p): p is Product => p !== undefined);
  }

  private isNaturalLanguageQuery(raw: string): boolean {
    const text = raw.trim().toLowerCase();
    const words = text.split(/\s+/).filter(Boolean);

    if (words.length >= 4) return true;

    const intent =
      /\b(under|below|over|above|less|more|than|cheap|cheapest|affordable|budget|best|top|good|great|premium|for|with|that|like|recommend|suggest|need|want|around|between|gaming|photography|work|travel|gift|student|business)\b/;
    if (intent.test(text)) return true;

    if (/\$|\d{3,}/.test(text)) return true;

    return false;
  }

  async searchByRelevance(query: string): Promise<Product[]> {
    const embedding = await this.embeddingService.generateEmbedding(query);
    const searchResults = await this.searchService.search(embedding, 10);

    if (searchResults.length === 0) return [];

    const ids = searchResults.map((r) => r.id);
    const rows = await this.prisma.product.findMany({
      where: { id: { in: ids } },
    });

    const productMap = new Map(rows.map((p) => [p.id, toProduct(p)]));
    return ids
      .map((id) => productMap.get(id))
      .filter((p): p is Product => p !== undefined);
  }

  async findAll(
    query: ProductQueryDto,
  ): Promise<{ products: Product[]; total: number }> {
    const hasFilters =
      query.search || query.category || query.minPrice || query.maxPrice;

    if (hasFilters) {
      let searchResults;

      if (query.search) {
        const filters = {
          category: query.category,
          minPrice: query.minPrice ? Number(query.minPrice) : undefined,
          maxPrice: query.maxPrice ? Number(query.maxPrice) : undefined,
        };

        if (this.isNaturalLanguageQuery(query.search)) {
          // Natural language → AI semantic search (embedding + kNN).
          const embedding = await this.embeddingService.generateEmbedding(
            query.search,
          );
          searchResults = await this.searchService.searchWithFilters({
            embedding,
            ...filters,
          });
        } else {
          // Simple keyword(s) → fast BM25 keyword search (no embedding cost).
          searchResults = await this.searchService.searchWithFilters({
            text: query.search,
            ...filters,
          });
        }
      } else {
        searchResults = await this.searchService.searchWithFilters({
          category: query.category,
          minPrice: query.minPrice ? Number(query.minPrice) : undefined,
          maxPrice: query.maxPrice ? Number(query.maxPrice) : undefined,
        });
      }
      if (searchResults.length === 0) {
        return { products: [], total: 0 };
      }

      const ids = searchResults.map((r) => r.id);
      const rows = await this.prisma.product.findMany({
        where: { id: { in: ids } },
      });
      const productMap = new Map(rows.map((p) => [p.id, toProduct(p)]));
      const ordered = ids
        .map((id) => productMap.get(id))
        .filter((p): p is Product => p !== undefined);

      return { products: ordered, total: ordered.length };
    }
    const rows = await this.prisma.product.findMany({
      orderBy: { rating: 'desc' },
    });
    const products = rows.map(toProduct);
    return { products, total: products.length };
  }

  async getDeals(): Promise<Product[]> {
    const now = new Date();
    const rows = await this.prisma.product.findMany({
      where: {
        salePrice: { not: null },
        OR: [{ dealExpiresAt: null }, { dealExpiresAt: { gt: now } }],
      },
      orderBy: { updatedAt: 'desc' },
    });
    return rows.map(toProduct);
  }

  async findById(id: string): Promise<Product | null> {
    const p = await this.prisma.product.findUnique({ where: { id } });
    return p ? toProduct(p) : null;
  }

  async getCategories(): Promise<string[]> {
    const results = await this.prisma.product.findMany({
      select: { category: true },
      distinct: ['category'],
      orderBy: { category: 'asc' },
    });
    return results.map((r) => r.category);
  }
}
