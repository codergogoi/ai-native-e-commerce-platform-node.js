import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import OpenAI from 'openai';
import { ProductsService } from '../products/products.service';
import { isProductOnDeal } from '../products/products.service';
import { ChatMessage, ChatStreamEvent } from './interfaces/chat.interface';
import { Product } from '../products/interfaces/product.interface';

interface CartLine {
  productId: string;
  name: string;
  price: number;
  quantity: number;
}

function briefProduct(p: Product) {
  return {
    id: p.id,
    name: p.name,
    price: p.price,
    salePrice: isProductOnDeal(p) ? p.salePrice : null,
    category: p.category,
    rating: p.rating,
    inStock: p.inStock,
  };
}

function cartSummary(cart: CartLine[]) {
  const total = cart.reduce((s, c) => s + c.price * c.quantity, 0);
  return {
    items: cart.map((c) => ({ name: c.name, quantity: c.quantity, price: c.price })),
    itemCount: cart.reduce((s, c) => s + c.quantity, 0),
    total: Number(total.toFixed(2)),
  };
}

@Injectable()
export class ChatService {
  private openai: OpenAI;

  constructor(
    private configService: ConfigService,
    private productsService: ProductsService,
  ) {
    this.openai = new OpenAI({
      apiKey: this.configService.get<string>('OPENAI_API_KEY'),
    });
  }
  private readonly tools: OpenAI.Chat.Completions.ChatCompletionTool[] = [
    {
      type: 'function',
      function: {
        name: 'show_products',
        description:
          'Show product cards to the user so they can browse and add to cart. Call this whenever you recommend or mention specific products.',
        parameters: {
          type: 'object',
          properties: {
            productIds: {
              type: 'array',
              items: { type: 'string' },
              description: 'Array of product IDs to show as cards',
            },
          },
          required: ['productIds'],
        },
      },
    },
    {
      type: 'function',
      function: {
        name: 'add_to_cart',
        description:
          "Add a product to the user's shopping cart. Use this when the user asks to add an item to their cart.",
        parameters: {
          type: 'object',
          properties: {
            productId: { type: 'string', description: 'The ID of the product to add to cart' },
          },
          required: ['productId'],
        },
      },
    },
    {
      type: 'function',
      function: {
        name: 'update_cart_quantity',
        description:
          "Update the quantity of a product in the user's cart. Use this when the user wants to change quantity, add multiple units, or increase/decrease the count of an item.",
        parameters: {
          type: 'object',
          properties: {
            productId: { type: 'string', description: 'The ID of the product to update' },
            quantity: { type: 'number', description: 'The new quantity to set (e.g., 2 for two units)' },
          },
          required: ['productId', 'quantity'],
        },
      },
    },
    {
      type: 'function',
      function: {
        name: 'place_order',
        description:
          'Navigate the user to the checkout page to complete their purchase. Use this when the user says "place order", "checkout", "buy now", or similar.',
        parameters: { type: 'object', properties: {}, required: [] },
      },
    },
    {
      type: 'function',
      function: {
        name: 'remove_from_cart',
        description:
          "Remove a product from the user's shopping cart. Use this when the user asks to remove an item from their cart.",
        parameters: {
          type: 'object',
          properties: {
            productId: { type: 'string', description: 'The ID of the product to remove from cart' },
          },
          required: ['productId'],
        },
      },
    },
    {
      type: 'function',
      function: {
        name: 'search_products',
        description:
          'Search the FULL product catalog by natural language with optional filters. Use this whenever the user asks about products that are not already in the AVAILABLE PRODUCTS list, or to find more/alternative options.',
        parameters: {
          type: 'object',
          properties: {
            query: { type: 'string', description: 'What to search for, e.g. "lightweight laptop for travel"' },
            category: { type: 'string', description: 'Optional category filter' },
            minPrice: { type: 'number', description: 'Optional minimum price' },
            maxPrice: { type: 'number', description: 'Optional maximum price' },
          },
          required: ['query'],
        },
      },
    },
    {
      type: 'function',
      function: {
        name: 'get_product_details',
        description: 'Fetch full details for a specific product id. Use for specs or precise comparisons.',
        parameters: {
          type: 'object',
          properties: { productId: { type: 'string', description: 'The product id' } },
          required: ['productId'],
        },
      },
    },
    {
      type: 'function',
      function: {
        name: 'get_deals',
        description: 'Get the current on-sale / discounted products.',
        parameters: { type: 'object', properties: {}, required: [] },
      },
    },
  ];
  private buildCartContext(cart: CartLine[]): string {
    if (!cart || cart.length === 0) return '';
    const lines = cart.map(
      (c) =>
        `- [ID: ${c.productId}] ${c.quantity}× ${c.name} @ $${c.price} = $${(c.price * c.quantity).toFixed(2)}`,
    );

    const total = cart.reduce((s, c) => s + c.price * c.quantity, 0);
    return `
CURRENT CART (${cart.length} item type(s), total $${total.toFixed(2)}):
${lines.join('\n')}
When the user asks about their cart or total, use THESE exact figures. After adding/removing items, state the updated total.
`;
  }

  private buildSystemPrompt(products: Product[], cart: CartLine[] = []): string {
    const productList = products
      .map((p) => {
        const onDeal = isProductOnDeal(p);
        const priceStr = onDeal
          ? `ON SALE $${p.salePrice} (was $${p.price})`
          : `$${p.price}`;
        return `- [ID: ${p.id}] ${p.name} (${priceStr}) [${p.category}]: ${p.description}. Features: ${p.features.join(', ')}. ${p.inStock ? 'In Stock' : 'Out of Stock'}. Rating: ${p.rating}/5`;
      })
      .join('\n');

    return `You are a friendly AI shopping assistant for an e-commerce store called "AI E-Commerce".
${this.buildCartContext(cart)}

YOUR ROLE:
- Recommend products by IMMEDIATELY calling the show_products function with product IDs
- Help customers compare options and make decisions
- Be enthusiastic but not pushy

AVAILABLE PRODUCTS:
${productList}

YOUR TOOLS (you are an agent: call tools, observe their results, then continue):
- search_products(query, filters): find ANY product in the full catalog. Use this whenever the user wants something not in the list above, more options, alternatives, or a different category/budget.
- get_product_details(productId): full specs for comparisons / detailed questions.
- get_deals(): current discounted products.
- show_products(productIds): display product cards to the user.
- add_to_cart / remove_from_cart / update_cart_quantity: manage the cart.
Always work from REAL data returned by these tools, never invent product ids, prices, or stock.
CART MANAGEMENT:
- "Add the best one" / "add it" means add EXACTLY ONE product (one add_to_cart call). Never add multiple products unless the user explicitly asks for several
- When the user says "add 2 iPhones", first call add_to_cart, then update_cart_quantity
- After adding, removing, or updating, confirm the action in a brief, friendly message
- To change a quantity call update_cart_quantity only. Call remove_from_cart only when the user asks to remove an item.

RULES:
- After any cart action, quote the updated cart total returned by the tool
- ALWAYS call show_products when you recommend or mention specific products
- Write a brief recommendation explaining why these products are great picks
- Recommend REAL products from the list above, never invent product ids, prices, or stock
- Keep responses short and friendly`;
  }
  async *streamChat(
    message: string,
    history: ChatMessage[],
    cart: CartLine[] = [],
  ): AsyncGenerator<ChatStreamEvent> {
    const relevantProducts =
      await this.productsService.searchByRelevance(message);

    const systemPrompt = this.buildSystemPrompt(relevantProducts, cart);
    const messages: OpenAI.Chat.Completions.ChatCompletionMessageParam[] = [
      { role: 'system', content: systemPrompt },
      ...history.map((h) => ({
        role: h.role as 'user' | 'assistant',
        content: h.content,
      })),
      { role: 'user' as const, content: message },
    ];

    const workingCart: CartLine[] = cart.map((c) => ({ ...c }));
    const MAX_ITERATIONS = 5;

    for (let iter = 0; iter < MAX_ITERATIONS; iter++) {
      const stream = await this.openai.chat.completions.create({
        model: 'gpt-4o-mini',
        stream: true,
        temperature: 0.7,
        tools: this.tools,
        parallel_tool_calls: false,
        messages,
      });

      let assistantText = '';
      const toolAcc: Record<number, { id: string; name: string; args: string }> = {};
      for await (const chunk of stream) {
        const choice = chunk.choices[0];
        if (!choice) continue;

        if (choice.delta?.content) {
          assistantText += choice.delta.content;
          yield { type: 'text', content: choice.delta.content };
        }

        for (const tc of choice.delta?.tool_calls ?? []) {
          const i = tc.index;
          if (!toolAcc[i]) toolAcc[i] = { id: '', name: '', args: '' };
          if (tc.id) toolAcc[i].id = tc.id;
          if (tc.function?.name) toolAcc[i].name = tc.function.name;
          if (tc.function?.arguments) toolAcc[i].args += tc.function.arguments;
        }
      }
      const toolCalls = Object.values(toolAcc).filter((t) => t.name);
      if (toolCalls.length === 0) {
        return;
      }

      messages.push({
        role: 'assistant',
        content: assistantText || null,
        tool_calls: toolCalls.map((t) => ({
          id: t.id,
          type: 'function',
          function: { name: t.name, arguments: t.args || '{}' },
        })),
      });

      for (const t of toolCalls) {
        let args: Record<string, any> = {};
        try {
          args = JSON.parse(t.args || '{}');
        } catch {
        }

        const result = yield* this.executeTool(t.name, args, {
          message,
          workingCart,
        });
        messages.push({
          role: 'tool',
          tool_call_id: t.id,
          content: JSON.stringify(result),
        });
      }
    }
  }

  private async *executeTool(
    name: string,
    args: Record<string, any>,
    ctx: { message: string; workingCart: CartLine[] },
  ): AsyncGenerator<ChatStreamEvent, unknown> {
    const { workingCart } = ctx;

    switch (name) {
      case 'search_products': {
        let found = await this.productsService.searchByRelevance(
          args.query || ctx.message,
        );
        if (args.category) {
          const c = String(args.category).toLowerCase();
          found = found.filter((p) => p.category.toLowerCase() === c);
        }
        if (args.minPrice != null) found = found.filter((p) => p.price >= args.minPrice);
        if (args.maxPrice != null) found = found.filter((p) => p.price <= args.maxPrice);
        return found.slice(0, 8).map(briefProduct);
      }
      case 'get_product_details': {
        const p = await this.productsService.findById(args.productId);
        return p ? p : { error: 'Product not found' };
      }
      case 'get_deals': {
        const d = await this.productsService.getDeals();
        return d.slice(0, 10).map(briefProduct);
      }
      case 'show_products': {
        const ids: string[] = args.productIds || [];
        if (ids.length) yield { type: 'products', productIds: ids };
        return { shown: ids.length };
      }
      case 'add_to_cart': {
        const p = args.productId
          ? await this.productsService.findById(args.productId)
          : null;
        if (!p) return { error: 'Product not found' };
        yield { type: 'cart_add', productId: p.id };
        const price = isProductOnDeal(p) ? (p.salePrice as number) : p.price;
        const line = workingCart.find((c) => c.productId === p.id);
        if (line) line.quantity += 1;
        else workingCart.push({ productId: p.id, name: p.name, price, quantity: 1 });
        return { added: p.name, cart: cartSummary(workingCart) };
      }
      case 'remove_from_cart': {
        if (!args.productId) return { error: 'Missing productId' };
        if (!workingCart.some((c) => c.productId === args.productId)) {
          return { error: 'Not in cart', cart: cartSummary(workingCart) };
        }
        yield { type: 'cart_remove', productId: args.productId };
        const idx = workingCart.findIndex((c) => c.productId === args.productId);
        const removed = idx >= 0 ? workingCart.splice(idx, 1)[0] : null;
        return { removed: removed?.name ?? 'item', cart: cartSummary(workingCart) };
      }
      case 'update_cart_quantity': {
        if (!args.productId || args.quantity == null) {
          return { error: 'Missing productId/quantity' };
        }
        if (!workingCart.some((c) => c.productId === args.productId)) {
          return { error: 'Not in cart', cart: cartSummary(workingCart) };
        }
        yield { type: 'cart_update_qty', productId: args.productId, quantity: args.quantity };
        const idx = workingCart.findIndex((c) => c.productId === args.productId);
        if (idx >= 0) {
          if (args.quantity <= 0) workingCart.splice(idx, 1);
          else workingCart[idx].quantity = args.quantity;
        }
        return { updated: true, cart: cartSummary(workingCart) };
      }
      case 'place_order': {
        yield { type: 'navigate', path: '/checkout' };
        return { navigatedTo: '/checkout', note: 'User taken to checkout page' };
      }
    }
  }
}
