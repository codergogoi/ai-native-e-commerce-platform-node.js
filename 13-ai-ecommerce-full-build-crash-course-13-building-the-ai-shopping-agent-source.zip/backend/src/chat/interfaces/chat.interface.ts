export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface ChatStreamEvent {
  type: 'text' | 'products' | 'cart_add' | 'cart_remove' | 'cart_update_qty' | 'navigate';
  content?: string;
  productIds?: string[];
  productId?: string;
  quantity?: number;
  path?: string;
}
