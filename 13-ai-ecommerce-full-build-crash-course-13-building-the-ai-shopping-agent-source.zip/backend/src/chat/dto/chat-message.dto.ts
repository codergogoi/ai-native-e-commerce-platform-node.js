import {
  IsString,
  IsArray,
  ValidateNested,
  IsIn,
  IsOptional,
  IsNumber,
} from 'class-validator';
import { Type } from 'class-transformer';

class HistoryMessageDto {
  @IsIn(['user', 'assistant'])
  role: 'user' | 'assistant';

  @IsString()
  content: string;
}

class CartLineDto {
  @IsString()
  productId: string;

  @IsString()
  name: string;

  @IsNumber()
  price: number;

  @IsNumber()
  quantity: number;
}

export class ChatMessageDto {
  @IsString()
  message: string;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => HistoryMessageDto)
  history: HistoryMessageDto[];

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CartLineDto)
  cart?: CartLineDto[];
}
